package test;

import com.company.Library;
import org.junit.Test;

/**
 * Created by Administrator on 20/07/2017.
 */
public class LibraryTest
{
    Library lib = new Library();

    @Test
    public void test()
    {
        System.out.println();
    }

 @Test public void testPerson ()
 {
     Person testing = new Person();
     
 }

}
