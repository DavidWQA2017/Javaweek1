
public class Dog implements CanBark {

}
