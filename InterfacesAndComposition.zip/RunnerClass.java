
public class RunnerClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Dog d = new Dog();
		d.bark();
		RobotDog rd = new RobotDog();
		rd.bark();
	}

}
