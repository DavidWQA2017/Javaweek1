
public interface CanBark {
	default public void bark() {
		System.out.println("Bark");
	}
}
