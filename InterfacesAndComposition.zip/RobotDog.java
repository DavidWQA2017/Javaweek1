
public class RobotDog implements CanBark {
	public void bark() {
		System.out.println("Bzzt Bark");
	}
}
